+++
about_text = "We strive to serve all our customers in the highest regard. We want customers to leave with confidence that their documents and plans are cared for, delivering the highest quality of service to our community."
headline = "Located in South Vancouver, we are situated on the intersection of Cambie Street and Southwest Marine Drive — easily accessible to the surrounding communities in Vancouver and Richmond."
layout = "location"
location_text = "We prepare the documents that are necessary to transfer the property and register the mortgage that secures your loan."
service_text = "At Marine Landing Notary Public,  we want to provide the best services to our clients and community. Here is how we can help and support your needs."
title = "Location"

+++
