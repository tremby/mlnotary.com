+++
hero_footer = "We prepare the documents that are necessary to transfer the property and register the mortgage that secures your loan."
hero_title = "Marine Landing Notary Public exists to provide services rooted in trust, quality assurance and excellent customer service to the community"
location_text = "Situated in the thriving neighbourhood on Cambie Street and Southwest Marine Drive, we are easily accessible to the surrounding communities in Vancouver and Richmond."
quote = "Here at Marine Landing Notary Public in Vancouver, we pride ourselves in quality assurance, excellent customer service, and building trust in the community. We want all our customers to leave with the confidence that their documents and plans are cared for and delivered in the highest quality."
service_text = "With a wide range of notary services from Wills and Estates to Mortgage Refinancing, find out how we can help and support your needs."
title = "Home"

+++
