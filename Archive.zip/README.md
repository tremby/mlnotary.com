## Templating Engine

Hugo Version 38.1

## Frontend Framework

SlashCSS 0.1.0
(Jin's custom CSS framework, documentation coming soon..)
